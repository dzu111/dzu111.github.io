<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartlibrary";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $genre_id = $conn->real_escape_string($_POST['genre_id']);

    $sql = "DELETE FROM genres WHERE genre_id='$genre_id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Genre deleted successfully'); window.location.href = 'genre_delete.html';</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "'); window.location.href = 'genre_delete.html';</script>";
    }

    $conn->close();
}
?>
