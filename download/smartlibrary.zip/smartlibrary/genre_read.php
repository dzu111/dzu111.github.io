<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Read Books</title>
    <link rel="stylesheet" href="menu.css">
</head>
<body> 
<h3>Read Genre</h3>
            <?php
            $conn = new mysqli("localhost", "root", "", "smartlibrary");
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM genres";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                echo "<table><tr><th>Genre ID</th><th>Book ID</th><th>Book Genre</th><th>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>".$row["genre_id"]."</td><td>".$row["books_id"]."</td><td>".$row["book_genre"]."</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
            $conn->close();
            ?>
     <br>
    <a href="menu_genre.html">Back to Genre</a>
</body>
</html>
