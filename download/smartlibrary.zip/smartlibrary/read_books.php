<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Read Books</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="content">
        <h2>Book List</h2>
        <?php
        $conn = new mysqli("localhost", "root", "", "smartlibrary");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT * FROM books";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<table><tr><th> ID</th><th>Book Title</th><th>Book Year</th><th>Book Quantity</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>".$row["books_id"]."</td><td>".$row["books_title"]."</td><td>".$row["books_year"]."</td><td>".$row["quantity"]."</td></tr>";
            }
            echo "</table>";
        } else {
            echo "0 results";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>
