<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Read Genre</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="content">
        <h2>Genre List</h2>
        <?php
        $conn = new mysqli("localhost", "root", "", "smartlibrary");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT * FROM genre";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<table><tr><th>Genre ID</th><th>Book ID</th><th>Book Genre</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>".$row["genre_id"]."</td><td>".$row["books_id"]."</td><td>".$row["book_genre"]."</td></tr>";
            }
            echo "</table>";
        } else {
            echo "0 results";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>
