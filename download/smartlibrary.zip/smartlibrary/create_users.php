<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartlibrary";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $users_name = $conn->real_escape_string($_POST['users_name']);
    $address = $conn->real_escape_string($_POST['address']);
    $phone = $conn->real_escape_string($_POST['phone']);

    $sql = "INSERT INTO users (users_name, address, phone) VALUES ('$users_name', '$address', '$phone')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New user created successfully'); window.location.href = 'user_insert.html';</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "'); window.location.href = 'user_insert.html';</script>";
    }

    $conn->close();
}
?>
