<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartlibrary";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $books_id = $conn->real_escape_string($_POST['books_id']);
    $book_genre = $conn->real_escape_string($_POST['book_genre']);

    $sql = "INSERT INTO genres (books_id, book_genre) VALUES ('$books_id', '$book_genre')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New genre created successfully'); window.location.href = 'index.html';</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "'); window.location.href = 'index.html';</script>";
    }

    $conn->close();
}
?>
