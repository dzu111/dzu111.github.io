<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Library</title>
    <link rel="stylesheet" href="menu.css">
</head>
<body>
    <marquee behavior="scroll" direction="right">
        <br>
        <img src="selamatdatang.png" alt="Welcome">
    </marquee>
    <center>
        <img src="tajuk.png" alt="Title">
        <h3>Sila pilih buku untuk dipinjam</h3>
    </center>
    <div>
        <h2>Smart Library</h2>
        <ul>
            <li><a href="home.html" target="kandungan">Home</a></li>
            <li><a href="menu_books.html" target="menu">Books</a></li>
            <li><a href="menu_genre.html" target="menu">Genre</a></li>
            <li><a href="menu_loan.html" target="menu">Loans</a></li>
            <li><a href="menu_user.html" target="menu">Users</a></li>
            <li><a href="logout.php">Log Out</a></li>
        </ul>
    </div>
</body>
</html>