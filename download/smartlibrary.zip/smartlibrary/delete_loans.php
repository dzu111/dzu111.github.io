<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartlibrary";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loans_id = $conn->real_escape_string($_POST['loans_id']);

    $sql = "DELETE FROM loans WHERE loans_id='$loans_id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('loan deleted successfully'); window.location.href = 'loan_delete.html';</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "'); window.location.href = 'loan_delete.html';</script>";
    }

    $conn->close();
}
?>
