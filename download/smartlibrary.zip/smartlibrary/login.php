<?php
session_start();
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $con = mysqli_connect('localhost', 'root', '', 'smartlibrary') or die('Unable To connect');
    $user_name = mysqli_real_escape_string($con, $_POST["user_name"]);
    $password = mysqli_real_escape_string($con, $_POST["password"]);
    
    $result = mysqli_query($con, "SELECT * FROM login_user WHERE user_name='$user_name' AND password='$password'");
    $row = mysqli_fetch_array($result);
    
    if (is_array($row)) {
        $_SESSION["user_id"] = $row['id']; 
        $_SESSION["name"] = $row['name'];
        header("Location: index.php");
    } else {
        $message = "Invalid Username or Password!";
    }
}
if (isset($_SESSION["user_id"])) {
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="borang.css">
<head>
    <title>User Login</title>
</head>
<body>
    <form name="frmUser" method="post" action="" align="center">
        <div class="message"><?php if ($message != "") { echo $message; } ?></div>
        <h3 align="center">Enter Login Details</h3>
        Username:<br>
        <input type="text" name="user_name">
        <br>
        Password:<br>
        <input type="password" name="password">
        <br><br>
        <input type="submit" name="submit" value="Submit">
        <input type="reset">
    </form>
</body>
</html>
