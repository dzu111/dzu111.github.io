
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Read Books</title>
    <link rel="stylesheet" href="menu.css">
</head>
<body> 
<h3>Read Loans</h3>
            <?php
            $conn = new mysqli("localhost", "root", "", "smartlibrary");
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM loans";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                echo "<table><tr><th>Loan ID</th><th>Book ID</th><th>User ID</th><th>Loan Date</th><th>Return Date</th></tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>".$row["loans_id"]."</td><td>".$row["books_id"]."</td><td>".$row["users_id"]."</td><td>".$row["loan_date"]."</td><td>".$row["return_date"]."</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
            $conn->close();
            ?>
     <br>
    <a href="menu_loan.html">Back to loans</a>
</body>
</html>
