<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartlibrary";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $books_id = $conn->real_escape_string($_POST['books_id']);

    $sql = "DELETE FROM books WHERE books_id='$books_id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Book deleted successfully'); window.location.href = 'index.html';</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "'); window.location.href = 'index.html';</script>";
    }

    $conn->close();
}
?>
