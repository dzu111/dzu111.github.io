<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Read Books</title>
    <link rel="stylesheet" href="menu.css">
</head>
<body>  
<h3>Read Users</h3>
            <?php
            $conn = new mysqli("localhost", "root", "", "smartlibrary");
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM Users";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                echo "<table><tr><th>ID</th><th>Name</th><th>Address</th><th>Phone Number</th></tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>".$row["users_id"]."</td><td>".$row["users_name"]."</td><td>".$row["address"]."</td><td>".$row["phone"]."</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
            $conn->close();
            ?>
    <br>
    <a href="menu_user.html">Back to User</a>
</body>
</html>