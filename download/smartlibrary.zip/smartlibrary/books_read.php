<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Read Books</title>
    <link rel="stylesheet" href="menu.css">
</head>
<body>
    <h3>Read Books</h3>
    <?php
    
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    
    $conn = new mysqli("localhost", "root", "", "smartlibrary");

   
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
    $sql = "SELECT * FROM books";
    $result = $conn->query($sql);

    
    if ($result->num_rows > 0) {
        echo "<table border='1'><tr><th>Book ID</th><th>Book Title</th><th>Book Year</th><th>Book Quantity</th></tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["books_id"] . "</td><td>" . $row["books_title"] . "</td><td>" . $row["books_year"] . "</td><td>" . $row["quantity"] . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "0 results";
    }

    $conn->close();
    ?>
    <br>
    <a href="menu_books.html">Back to Books</a>
</body>
</html>
